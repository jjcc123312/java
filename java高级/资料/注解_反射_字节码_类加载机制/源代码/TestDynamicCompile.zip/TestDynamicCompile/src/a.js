//定义test方法
function test(){
	var a = 3;
	var b = 4;
	println("invoke js file:"+(a+b));
}

//执行test方法
test();