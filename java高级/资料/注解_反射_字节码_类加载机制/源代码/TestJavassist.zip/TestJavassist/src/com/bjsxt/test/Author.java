package com.bjsxt.test;
public @interface Author { 
          String name(); 
           int year();
 }
